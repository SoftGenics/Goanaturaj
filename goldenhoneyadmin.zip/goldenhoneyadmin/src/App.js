import React from "react";
import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";
import Login from "./Components/Login/Login";
import LogOut from "./Components/Login/Logout";
import Dashboard from "./Components/Dashboard/Dashboard";
import Hairs from "./Components/Hairs/Hairs";
import AddHairs from "./Components/Hairs/AddHairs";
import ViewHairsProduct from "./Components/Hairs/ViewHairsProduct";
function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/logout" element={<LogOut />} />
      <Route path="/Dashboard" element={<Dashboard />} />
      <Route path="/Hairs" element={<Hairs />} />
      <Route path="/AddHairsProducts" element={<AddHairs />} />
      <Route path="/ViewHairsProducts/:id" element={<ViewHairsProduct />} />
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
