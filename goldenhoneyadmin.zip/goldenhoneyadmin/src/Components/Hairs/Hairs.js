import React,{useState, useEffect} from 'react'
import {Table, Container,  Button} from 'react-bootstrap'
import SideBar from '../SideBar/SideBar'
import axios from 'axios';
import './Hairs.css'
import { Link, useNavigate } from 'react-router-dom';

const Hairs = () => {
  let navigate = useNavigate();
  const token = localStorage.getItem("token")
  let loggedIn = true
  if(token ==  null){
    loggedIn= false
  }
 const [login ] = useState(loggedIn)
  
 if(login === false){
  navigate('/')
}
 
    const [GetData, SetPost] = useState([]);
useEffect(() => {

  const fetchPosts = async () =>{
    const res = await axios.get("http://localhost:5000/api/allHair");
    SetPost(res.data)
  }
  fetchPosts();
},[]);

const deleteHairProduct = async id => {
  await axios.delete(`http://localhost:5000/api/deletehairProduct/${id}`)
  window.location.reload();

}
  return (
    <div>
        <SideBar />
            <Container className='hairs'>
                <h1 className='text-center mt-3'>Hairs</h1>
                <Table striped bordered hover className='table border shadow text-center mt-5'responsive="sm" >
          <thead>
            <tr>
              <th>Image</th>
              <th>Product Name</th>
              <th>Product Subname</th>
              <th>Price</th>
              <th>Price(s)</th>
              <th>Price(m)</th>
              <th>Price(l)</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
          
            { GetData.map((getData) =>{
      

      
      return(
          <>
            <tr>
              <td><img  src={`http://localhost:5000/uploads/${getData.picture}`} alt="hairs products" style={{width:'50px', height:'50px'}} /></td>
              <td>{getData.p_name}</td>
              <td>{getData.p_subname}</td>
              <td>{getData.price}</td>
              <td>{getData.price_s}</td>
              <td>{getData.price_m}</td>
              <td>{getData.price_l}</td>

              <td>
                <Link to={`/ViewHairsProducts/${getData.id}`} className='btn btn-primary  '><i className="far fa-eye"></i></Link>
                <Link  className='mx-3 btn btn-outline-secondary' to={`/update_doctor/${getData.id}`}><i className="fas fa-edit"></i></Link>
                <Button className='btn btn-danger' onClick={() => deleteHairProduct(getData.id)} ><i className="fas fa-trash-alt"></i></Button>
              </td>
            </tr>
           
          </>
              )

        }
      )}
          </tbody>
        </Table>
        <Link to="/AddHairsProducts" className="float">
            <i className="fas fa-plus my-float"></i>
            </Link>
            </Container>
    </div>
  )
}

export default Hairs