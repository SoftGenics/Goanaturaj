import React from 'react'

const UpdateHairProduct = () => {
  return (
    <div>UpdateHairProduct</div>
  )
}

export default UpdateHairProduct