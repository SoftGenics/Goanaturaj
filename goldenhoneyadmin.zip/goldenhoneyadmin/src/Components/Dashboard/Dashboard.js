import React,{Component} from 'react'
import Sidebar from '../SideBar/SideBar'
import { Navigate } from 'react-router-dom'
export default class dashboard extends Component {
    constructor(props){
      super(props)
      const token = localStorage.getItem("token")
      let loggedIn = true
      if(token ==  null){
        loggedIn= false
      }
      this.state = {
        loggedIn
      }
  
    }

  render() 
  {    if(this.state.loggedIn === false){
    return <Navigate to="/" />
  }
      return (
          <div>
              <Sidebar />
              dashboard
          </div>
      )
  }
}